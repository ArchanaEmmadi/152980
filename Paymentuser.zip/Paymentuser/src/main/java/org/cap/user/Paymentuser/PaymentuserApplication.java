package org.cap.user.Paymentuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentuserApplication.class, args);
	}
}
