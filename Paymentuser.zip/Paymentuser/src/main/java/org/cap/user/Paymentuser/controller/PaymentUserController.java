package org.cap.user.Paymentuser.controller;




import java.util.HashMap;
import java.util.Map;

import org.cap.user.Paymentuser.model.BankAccount;
import org.cap.user.Paymentuser.model.Order;
import org.cap.user.Paymentuser.model.Transaction;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class PaymentUserController {

	@RequestMapping("/paymentSuccess/credit/{creditCardNum}/{creditCardCvv}")
	public String makeCreditPayment(@PathVariable("creditCardNum") long creditCardNum, @PathVariable("creditCardCvv") long creditCardCvv, ModelMap map){
		
		final String uri="http://localhost:8088/capstoreApp/api/v1/checkCard";
		RestTemplate restTemplate=new RestTemplate();
		
		Map<String,Object> params=new HashMap<>();
		params.put("creditCardNum", creditCardNum);
		params.put("creditCardCvv", creditCardCvv);
		
		BankAccount cardCheck= restTemplate.getForObject(uri, BankAccount.class,params);
		if(cardCheck == null) {
			map.put("errorCard", "Card Number not valid");
			
			return "redirect:/paymentCap";
		}
		else {
			final String uri_credit="http://localhost:8088/capstoreApp/api/v1/creditCard";
			RestTemplate restTemplate_card=new RestTemplate();
			
			Map<String,Object> param=new HashMap<>();
			params.put("creditCardNum", creditCardNum);
			params.put("creditCardCvv", creditCardCvv);
			
			Transaction t = new Transaction();
			t.setAmount(5400);
			t.setModeOfPurchase("credit");
			t.setStatus("success");
			
			restTemplate_card.postForEntity(uri_credit, t, Transaction.class);
			
		}
		
		return "paymentSuccessfull";
	}
	
	@RequestMapping("/paymentSuccessfull")
	public String getSuccessPage() {
		return "paymentSuccessfullCap";
	}
}
