package org.cap.user.Paymentuser.controller;




import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cap.user.Paymentuser.model.BankAccount;
import org.cap.user.Paymentuser.model.Order;
import org.cap.user.Paymentuser.model.Transaction;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class PaymentUserController {

	
	@RequestMapping("/paymentCap")
	public String getPaymentPage() {
		return "PaymentCap";
	}
	@RequestMapping("/paymentSuccess/credit/{creditCardNum}/{creditCardCvv}")
	public String makeCreditPayment(@PathVariable("creditCardNum") long creditCardNum, @PathVariable("creditCardCvv") int creditCardCvv, ModelMap map){
		
		final String uri="http://localhost:8088/capstoreApp/api/v1/checkCard/{creditCardNum}/{creditCardCvv}";
		RestTemplate restTemplate=new RestTemplate();
		Map<String,Object> params=new HashMap<>();
		params.put("creditCardNum", creditCardNum);
		params.put("creditCardCvv", creditCardCvv);
		BankAccount cardCheck= restTemplate.getForObject(uri, BankAccount.class,params);
		
		
		if(cardCheck == null) {
			map.put("errorCard", "Card Number not valid");
			return "redirect:/paymentCap";
		}
		else {
			final String uri_credit="http://localhost:8088/capstoreApp/api/v1/creditCard";
			RestTemplate restTemplate_card=new RestTemplate();
			
			Transaction t = new Transaction();
			t.setAmount(5400);
			t.setModeOfPurchase("credit");
			t.setStatus("success");
			
			restTemplate_card.postForEntity(uri_credit, t, Transaction.class);
			
		}
		
		return "paymentSuccessfull";
	}
	
	@RequestMapping("/paymentSuccessfull")
	public String getSuccessPage() {
		return "paymentSuccessfullCap";
	}
	@RequestMapping("/paymentSuccess/debit/{debitCardNum}/{debitCardCvv}")
	public String makeDebitPayment(@PathVariable("debitCardNum") long debitCardNum, @PathVariable("debitCardCvv") int debitCardCvv, ModelMap map){
		
		final String uri="http://localhost:8088/capstoreApp/api/v1/checkDebitCard/{debitCardNum}/{debitCardCvv}";
		RestTemplate restTemplate=new RestTemplate();
		
		Map<String,Object> params=new HashMap<>();
		params.put("debitCardNum", debitCardNum);
		params.put("debitCardCvv", debitCardCvv);
		
		BankAccount cardCheck= restTemplate.getForObject(uri, BankAccount.class,params);
		if(cardCheck == null) {
			map.put("errorCard", "Card Number not valid");
			
			return "redirect:/paymentCap";
		}
		else {
			final String uri_debit="http://localhost:8088/capstoreApp/api/v1/debitCard";
			RestTemplate restTemplate_card=new RestTemplate();
			
			Transaction t = new Transaction();
			t.setAmount(5400);
			t.setModeOfPurchase("debit");
			t.setStatus("success");
			
			restTemplate_card.postForEntity(uri_debit, t, Transaction.class);
			
		}
		
		return "paymentSuccessfull";
	}
	@RequestMapping("/paymentSuccess/netB/{netBankingNum}")
	public String makeNetBankingPayment(@PathVariable("netBankingNum") long netBankingNum,ModelMap map){
		
		final String uri="http://localhost:8088/capstoreApp/api/v1/checkNetBankCard/{netBankingNum}";
		RestTemplate restTemplate=new RestTemplate();
		
		Map<String,Object> params=new HashMap<>();
		params.put("netBankingNum", netBankingNum);
		
		BankAccount cardCheck= restTemplate.getForObject(uri, BankAccount.class,params);
		if(cardCheck == null) {
			map.put("errorCard", "Card Number not valid");
			
			return "redirect:/paymentCap";
		}
		else {
			final String uri_netB="http://localhost:8088/capstoreApp/api/v1/netBanking";
			RestTemplate restTemplate_card=new RestTemplate();
			
			Transaction t = new Transaction();
			t.setAmount(5400);
			t.setModeOfPurchase("netBanking");
			t.setStatus("success");
			
			restTemplate_card.postForEntity(uri_netB, t, Transaction.class);
			
		}
		
		return "paymentSuccessfull";
	}
	@RequestMapping("/paymentSuccess/cod")
	public String makeCashOnDeliveryPayment(){
		
		final String uri_COD="http://localhost:8088/capstoreApp/api/v1/cashOnDelivery";
			RestTemplate restTemplate_card=new RestTemplate();
			Transaction t = new Transaction();
			t.setAmount(5400);
			t.setModeOfPurchase("Cash on delivery");
			t.setStatus("success");
			
			restTemplate_card.postForEntity(uri_COD, t, Transaction.class);
			return "paymentSuccessfull";
			
	}
	/*@RequestMapping("/PaymentCap")
	public String getPaymentCapForm(ModelMap map) {
		
		
		final String uri="http://localhost:8088/capstoreApp/api/v1/accounts";
		RestTemplate restTemplate=new RestTemplate();
		
		BankAccount[] bank= restTemplate.getForObject(uri, BankAccount[].class);
		
		
		map.put("accounts",bank);
		map.put("bankAccount", new BankAccount());
		
		return "PaymentCap";
	}*/
	/*@GetMapping("/getAccounts")
	public ResponseEntity<List<BankAccount>> getAllBankAccounts(@RequestParam("cardNo") Long cardNumber,
			@RequestParam("cardcvv") Integer cvvNumber,@RequestParam("netbank") Long accountNumber){*/
		/*List<BankAccount> bAccounts= paymentService.getAllbAccounts();
		List<BankAccount> accounts=new ArrayList();*/
		
		//BankAccount bank=new BankAccount();
		/*for (BankAccount a : bAccounts) {
			if((a.getCardNumber()==(cardNumber))&& (a.getCvvNumber()==(cvvNumber)) ){
				
				
				bank.setCardNumber(a.getCardNumber());
				bank.setCvvNumber(a.getCvvNumber());
				accounts.add(bank);
				}
		}
		if(bAccounts.isEmpty()||bAccounts==null)
			return new ResponseEntity
				("Sorry! No account details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<BankAccount>>(bAccounts,HttpStatus.OK);*/
	
}
