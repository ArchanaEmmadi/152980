package com.wallet;

import java.util.Scanner;


import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import java.util.*;

import com.walletException.WalletException;
import com.walletService.WalletService;
import com.walletService.WalletServiceImp;



/**
 * Hello world!
 *
 */
public class App 
{
	Scanner scan=new Scanner(System.in);
	WalletService walletService=new WalletServiceImp();
	Customer c=new Customer();
	
    public static void main( String[] args )
    {
    	App a=new App();
		a.scan.useDelimiter("\n");
	String option=null;
	while(true)
	{
	System.out.println("\n===Banking application===");
	System.out.println("1.Create Account\n2.show Balance\n3.Deposit\n4.Withdraw\n5.funds Transfer\n6.Print Transaction\n7.exit");
	System.out.println("enter your choice");
	option=a.scan.nextLine();
	
	switch(option) {
	case "1":
		a.createAccount();
		break;
	case "2":
		a.showBalance();
		break;
	case "3":
		a.deposite();
		break;
	case "4":
		a.withdraw();
		break;
	case "5":
		a.fundsTransfer();
		break;
	case "6":
		a.printTransaction();
		break;
	case "7":
		System.exit(0);
		break;
		default:
			System.out.println("enter valid option within 1 and 7");
			break;
	}
	}
    }
	public void printTransaction() {
//		System.out.println("enter customer Account number");
//		long ac=Long.parseLong(scan.nextLine());
//		System.out.println("enter password");
//	    String pwd=scan.nextLine();
//	    try {
//			boolean result=walletService.validate(ac,pwd);
//			if(result) {
//				Transaction t=walletService.printTransactions(ac);
//				System.out.println(t);
//			}else
//			{
//				System.err.println("enter valid details");
//			}
//			
//		} catch (WalletException e) {
//			System.err.println("an error occured"+e.getMessage());
//		}
		
		try{
			System.out.println("enter account no:");
			long accno=Long.parseLong(scan.nextLine());
			HashMap<String,Transaction> list=walletService.printTransactions(accno);
			
			if(list != null) {
				for(Map.Entry<String, Transaction> T: list.entrySet()) {
					System.out.println();
					System.out.println("Transaction ID: " + T.getKey());
					System.out.println("Transaction type: "+ T.getValue().getTranstype().toString());
					System.out.println("Date : "+ T.getValue().getDate().toString());
					System.out.println("Amount: " + T.getValue().getAmount());
					System.out.println("Account Number: "+ T.getValue().getAccount_number());
					System.out.println();
				}
			/*Iterator itr=list.iterator();
			while(itr.hasNext())
			{
				System.out.println(itr.next());
			}*/
			}
			else {
				throw new WalletException("No data to show");
			}
			
		}
		catch (WalletException e) {
		System.err.println("an error occured"+e.getMessage());
	}
		
		
	}
	public void fundsTransfer() {
		System.out.println("enter customer Account number");
		long ac=Long.parseLong(scan.nextLine());
		System.out.println("enter customer Account number which u want to tranfer the money");
		long ac1=Long.parseLong(scan.nextLine());
		System.out.println("enter password");
	    String pwd=scan.nextLine();
	    try {
			boolean result=walletService.validate(ac,pwd);
			if(result) {
				System.out.println("enter amount to be transfered");
				double amt=Double.parseDouble(scan.nextLine());
				double newbal=walletService.fundsTransfer(ac,ac1,amt);
				System.out.println("account balance : "+newbal);
			}
			
		} catch (WalletException e) {
			System.err.println("an error occured"+e.getMessage());
		}
		
	}
	public void withdraw() {
		System.out.println("enter customer Account number");
		long ac=Long.parseLong(scan.nextLine());
		System.out.println("enter password");
	    String pwd=scan.nextLine();
	    try {
			boolean result=walletService.validate(ac,pwd);
			if(result) {
				System.out.println("enter ammount to be withdrawed");
				double amt=Double.parseDouble(scan.nextLine());
				double newbal=walletService.withdraw(ac,amt);
				System.out.println(+amt+ "is withdrawed in account number "+ac);
				System.out.println("account balance : "+newbal);
			}
			
		} catch (WalletException e) {
			System.err.println("an error occured"+e.getMessage());
		}
		
	}
	public void deposite() {
		System.out.println("enter customer Account number");
		long ac=Long.parseLong(scan.nextLine());
		System.out.println("enter password");
	    String pwd=scan.nextLine();
	    try {
			boolean result=walletService.validate(ac,pwd);
			if(result) {
				System.out.println("enter ammount to be deposited");
				double amt=Double.parseDouble(scan.nextLine());
				double newbal=walletService.deposite(ac,amt);
				System.out.println(+amt+ "is deposited into account number "+ac);
				System.out.println("account balance : "+newbal);
			}
			
		} catch (WalletException e) {
			System.err.println("an error occured"+e.getMessage());
		}
		
	}
		
	public void showBalance() {
		System.out.println("enter customer Account number");
		long ac=Long.parseLong(scan.nextLine());
		System.out.println("enter password");
	    String pwd=scan.nextLine();
	    try {
			boolean result=walletService.validate(ac,pwd);
			if(result) {
			double bal= walletService.showBalance(ac);
			System.out.println("Account balance : "+bal);
			}
			
		} catch (WalletException e) {
			System.err.println("an error occured"+e.getMessage());
		}
		
	}
	public void createAccount() {
		
		System.out.println("enter customer Name");
		c.setCustomerName(scan.nextLine());
		System.out.println("enter customer Account Type");
		c.setAccountType(scan.nextLine());
		System.out.println("enter password");
	    c.setPassword(scan.nextLine());
	    System.out.println("enter mobile number");
		c.setMobile(scan.nextLine());
		System.out.println("enter email");
	    c.setEmail(scan.nextLine());
	    System.out.println("enter address");
	    c.setAddress(scan.nextLine());
	    System.out.println("enter age");
	    c.setAge(scan.nextLine());
	    c.setBalance(1000);
	    try {
			boolean result=walletService.validateCustomer(c);
			if(result) {
			long ret= walletService.createAccount(c);
			System.out.println("customer with id"+ret+"created succesfully");
			}
			
		} catch (WalletException e) {
			System.err.println("an error occured"+e.getMessage());
		}
	
	
		
	}
}
