package com.wallet.bean;

import java.util.ArrayList;

public class Customer {
	public Customer(){
		
	}
	private long accountNumber;
	private String accountType;
	private String CustomerName;
	private double balance;
	private String age;
	private String password;
	
	ArrayList<String> list=new ArrayList<String>();
	
	public String getAge() {
		return age;
	}
	public ArrayList<String> getList() {
		return list;
	}
	public void setList(ArrayList<String> list) {
		this.list = list;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	private String mobile;
	private String email;
	private String address;
	
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Customer(long accountNumber, String accountType, String customerName, double balance, String age,
			String password, String mobile, String email, String address) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		CustomerName = customerName;
		this.balance = balance;
		this.age = age;
		this.password = password;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
	}
	public String toString() {
		return "balance"+balance;
	}
	
	
}
