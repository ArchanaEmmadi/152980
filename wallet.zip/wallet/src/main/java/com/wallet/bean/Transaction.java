package com.wallet.bean;

import java.time.LocalDate;
import java.util.HashMap;

public class Transaction {
	
 private String transtype;
 private LocalDate date;
 private double amount;
 private long account_number;
 
 private static HashMap<String,Transaction> transactionMap = new HashMap<>();
 
 public static HashMap<String,Transaction> getTransactionMap(){
	 return transactionMap;
 }
 
public String getTranstype() {
	return transtype;
}
public void setTranstype(String transtype) {
	this.transtype = transtype;
}
public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}


public long getAccount_number() {
	return account_number;
}

public void setAccount_number(long account_number) {
	this.account_number = account_number;
}

public Transaction(String transtype, LocalDate date, double amount, long account_number) {
	super();
	this.transtype = transtype;
	this.date = date;
	this.amount = amount;
	this.account_number = account_number;
}
public Transaction() {
	super();
	
}
public String toString()
{
	return "transtype: "+getTranstype()+" date :"+getDate()+" amount : "+getAmount();
}
}
