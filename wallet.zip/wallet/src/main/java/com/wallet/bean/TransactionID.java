package com.wallet.bean;

public class TransactionID {

	private String transactionId;

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public TransactionID(String transactionId) {
		super();
		this.transactionId = transactionId;
	}

	public TransactionID() {
		super();
		this.transactionId = ""+System.currentTimeMillis();
	}
	
}
