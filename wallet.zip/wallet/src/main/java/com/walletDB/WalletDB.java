package com.walletDB;

import java.util.HashMap;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;



public class WalletDB {
	private static HashMap<Long,Customer>
	customerDetails=new HashMap<Long,Customer>();
	private static HashMap<Long,Transaction>
	transactionDetails=new HashMap<Long,Transaction>();                          
	public static HashMap<Long, Transaction> getTransactionDetails() {
		return transactionDetails;
	}
	static {
		customerDetails.put(100123456789l,new Customer(100123456789l,"savings","archana",1000d,"18","archu2412","9834455765","archana@gmail.com","balkampet"));
		customerDetails.put(100123456788l,new Customer(100123456788l,"current","sai",1000d,"20","sai2412","9834455767","sai@gmail.com","bal"));
		customerDetails.put(100123456787l,new Customer(100123456787l,"savings","chitti",1000d,"76","chitti2412","9834455763","chitti@gmail.com","ameerpet"));
	}
	public static HashMap<Long, Customer> getCustomerDetails() {
		return customerDetails;
	}
	
}
