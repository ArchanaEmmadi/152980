package com.walletDAO;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.bean.TransactionID;
import com.walletDB.WalletDB;
import com.walletException.WalletException;

public class WalletDAOImp implements WalletDAO{
	
	static HashMap<Long,Customer> accountMap=WalletDB.getCustomerDetails();
	static HashMap<Long, Transaction> transactionMap=WalletDB.getTransactionDetails();
	static HashMap<String, Transaction> tMap = Transaction.getTransactionMap();
	
			Transaction transaction=new Transaction();
	
	public long createAccount(Customer c) throws WalletException {
		
		try {
			if(accountMap.size()==0) {
				c.setAccountNumber(100123456789l);
			}
			else {
				Optional<Long> id=accountMap.keySet().stream().max((x,y)->x>y?1:0);
				long reqid=id.get()+1;
				
				c.setAccountNumber(reqid);
			}
			
			accountMap.put(c.getAccountNumber(),c);
			TransactionID tId = new TransactionID();
			tMap.put(tId.getTransactionId(), new Transaction("deposit", LocalDate.now(), 1000, c.getAccountNumber()));
			return c.getAccountNumber();
		}catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public double showBalance(long ac) throws WalletException {
		Customer c=accountMap.get(ac);
		if(c==null)
			 throw new WalletException("account id" + ac+" does not exist" );
			return c.getBalance();
	}

	@Override
	public boolean validate(long ac, String pwd) throws WalletException {
		Customer c=accountMap.get(ac);
		try {
			if(pwd==null)
				throw new WalletException("Account number is invalid");
			if(c.getPassword().equalsIgnoreCase(pwd))
			return true;
			else
				throw new WalletException("enter correct pin");
		}catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public double deposite(long ac, double amt) throws WalletException {
				try {
					Customer c=accountMap.get(ac);
			c.setBalance(c.getBalance()+amt);
			
			TransactionID tId = new TransactionID();
			tMap.put(tId.getTransactionId(), new Transaction("deposit", LocalDate.now(),amt, ac));
			return c.getBalance();
		}
				catch(Exception ex)
				{
					throw new WalletException(ex.getMessage());
				}
	}

	@Override
	public double withdraw(long ac, double amt) throws WalletException {
		try {
			Customer c=accountMap.get(ac);
	c.setBalance(c.getBalance()-amt);
	
	TransactionID tId = new TransactionID();
	tMap.put(tId.getTransactionId(), new Transaction("withdraw", LocalDate.now(), -amt, ac));
	return c.getBalance();
}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public double fundsTransfer(long ac, long ac1, double amt) throws WalletException {
		try {
			Customer c=accountMap.get(ac);
			Customer c1=accountMap.get(ac1);
			if(c==null)throw new WalletException("enter correct account number");
			if(c1==null)throw new WalletException("enter correct account number which to be transefered");
			if(c==c1)throw new WalletException("u cannot transfer to ur account");
			else
			{
				double a=c.getBalance();
				if(amt<=0)
					throw new WalletException("enter amount greater then zero");
				else if(a<amt)
					throw new WalletException("insufficent balance in your account");
				else
				{
					c.setBalance(c.getBalance()-amt);
					c1.setBalance(c1.getBalance()+amt);
					transaction.setAmount(amt);
					transaction.setDate(LocalDate.now());
					transaction.setTranstype("funds transfer");
					transactionMap.put(ac1,transaction);
					
					TransactionID tId = new TransactionID();
					tMap.put(tId.getTransactionId(), new Transaction("transfer",LocalDate.now() ,amt, ac));
					
					return c.getBalance();
				}
			}
	}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	

}

	@Override
	public HashMap<String,Transaction> printTransactions(long accountNo) throws WalletException {
		
		
		HashMap<String,Transaction> result = new HashMap<String,Transaction>();
	    
	    for(Map.Entry<String, Transaction> T: tMap.entrySet()) {
	    	
	    	if(T.getValue().getAccount_number() == accountNo) {
	    		result.put(T.getKey(), T.getValue());
	    	}
	    }
		
	    return result;
		/*Customer c=new Customer();
		Set s=accountMap.entrySet();
		Iterator itr=s.iterator();
		while (itr.hasNext()) {
			Map.Entry me=(Map.Entry)itr.next();
			if(accountNo==(long)me.getKey())
			{
				c=(Customer)me.getValue();
				
			}
			else
			{
				return null;
			}
		}

		return c.getList();*/
	}

	//@Override
	/*public Transaction printTransactions(long ac) throws WalletException {
		// TODO Auto-generated method stub
		return transaction;
	}*/
	
}