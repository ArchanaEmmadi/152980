package com.walletDAO;

import java.util.ArrayList;
import java.util.HashMap;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.walletException.WalletException;

public interface WalletDAO {
	

	long createAccount(Customer c)throws WalletException;
	boolean validate(long ac, String pwd)throws WalletException;
	double showBalance(long ac)throws WalletException;
	double deposite(long ac, double amt)throws WalletException;
	double withdraw(long ac, double amt)throws WalletException;
	double fundsTransfer(long ac, long ac1, double amt)throws WalletException;
	//Transaction printTransactions(long ac)throws WalletException;
	public HashMap<String,Transaction> printTransactions(long accountNo) throws WalletException;
}
