package com.walletTest;

import static org.junit.Assert.*;

import org.junit.Test;

import com.walletDAO.WalletDAO;

public class WalletDAOImpTest {

	
	@Test
	public void testCreateAccount() {
		
	}

	@Test
	public void testShowBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposite() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundsTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransactions() {
		fail("Not yet implemented");
	}

}
