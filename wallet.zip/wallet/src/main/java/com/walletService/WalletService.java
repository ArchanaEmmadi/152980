package com.walletService;



import com.wallet.bean.Transaction;

import java.util.ArrayList;
import java.util.HashMap;

import com.wallet.bean.Customer;
import com.walletException.WalletException;

public interface WalletService {
	boolean validateName(String name) throws WalletException;
	boolean validateMobile(String mobile) throws WalletException;
	boolean validateEmail(String email) throws WalletException;
	public boolean validateCustomer(Customer c) throws WalletException;
	boolean validatePassword(String password) throws WalletException;
	boolean validateAddress(String address) throws WalletException;
	boolean validateAge(String age) throws WalletException;
	long createAccount(Customer c) throws WalletException;
	
	double showBalance(long ac)throws WalletException;
	boolean validate(long ac, String pwd)throws WalletException;
	double deposite(long ac, double amt)throws WalletException;
	double withdraw(long ac, double amt)throws WalletException;
	double fundsTransfer(long ac, long ac1, double amt)throws WalletException;
	//Transaction printTransactions(long ac)throws WalletException;
	public HashMap<String,Transaction> printTransactions(long accountNo) throws WalletException;
	
}
