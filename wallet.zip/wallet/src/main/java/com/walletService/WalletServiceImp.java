package com.walletService;

import java.util.ArrayList;
import java.util.HashMap;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;

import com.walletDAO.WalletDAO;
import com.walletDAO.WalletDAOImp;
import com.walletException.WalletException;

public class WalletServiceImp implements WalletService{
	WalletDAO walletDAO=new WalletDAOImp();
	public boolean validateCustomer(Customer c) throws WalletException {
		if(validateName(c.getCustomerName())&&validateMobile(c.getMobile())&&validateEmail(c.getEmail())
				&& validatePassword(c.getPassword()) && validateAddress(c.getAddress())  && validateAge(c.getAge()) && validateAccountType(c.getAccountType())){
			return true;
		}
		
		return false;
	}
	public boolean validateName(String name) throws WalletException {
		if(name.isEmpty() || name==null) {
			throw new WalletException("employee name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("name should start with a capital letter followed by a min of 2 alphabets");
			}
		}
		
		return true;
	}
	public boolean validateMobile(String mobile) throws WalletException{
		if(mobile.isEmpty()|| mobile==null) {
			throw new WalletException("mobile num is mandatory");
			
		}
		else {
			if(!mobile.matches("\\d{10}")){
				throw new WalletException("mobile number should contain only 10 digits");
				
			}
		}
		return true;
	}
public boolean validateEmail(String email) throws WalletException{
	if(!email.matches("[A-Za-z0-9_]+@[a-z]+\\.com")) {
		throw new WalletException("please enter a valid email id");
		
		
	}
	return true;
}
@Override
public long createAccount(Customer c) throws WalletException {
	
	return walletDAO.createAccount(c);
}
@Override
public boolean validatePassword(String password) throws WalletException {
	
	if(password.isEmpty() || password==null) {
		throw new WalletException("password cannot be empty");
	}
	else {
		if(!password.matches("[A-Za-z][a-zA-Z0-9]{8,}")) {
			throw new WalletException("password should be min of 8 alphabets");
		}
	}
	
	return true;
}
public boolean validateAccountType(String accountType) throws WalletException {
	
	if(accountType.isEmpty() || accountType==null) {
		throw new WalletException("Account Type cannot be empty");
	}
	
	else {
		if(!(accountType.equalsIgnoreCase("Savings") ||accountType.equalsIgnoreCase("Current")||accountType.equalsIgnoreCase("Salary")))
			throw new WalletException("Account Type should be Saving, Current or Salary Account");
	}
	return true;
}
public boolean validateAddress(String address) throws WalletException {
	
	if(address.isEmpty() ||address==null) {
		throw new WalletException("address cannot be empty");
	}
	else {
		if(!address.matches("[A-Z][A-Za-z]{2,}")) {
			throw new WalletException("address should be min of 2 alphabets");
		}
	}
	
	return true;
}
public boolean validateAge(String age) throws WalletException {
	
	if(age.isEmpty() ||age==null) {
		throw new WalletException("age cannot be empty");
	}
	else 
		if(age.matches("[A-Z][A-Za-z]{2,}")) {
			throw new WalletException("incorrect age");
		
	}
	else
	{
		if(Integer.parseInt(age)<18 || Integer.parseInt(age)>120)
			throw new WalletException("invalid age");
	}
	return true;
}


@Override
public double showBalance(long ac) throws WalletException {
	// TODO Auto-generated method stub
	return walletDAO.showBalance(ac);
}
@Override
public boolean validate(long ac, String pwd) throws WalletException {
	
	return walletDAO.validate(ac,pwd);
}
@Override
public double deposite(long ac, double amt) throws WalletException {
	// TODO Auto-generated method stub
	return walletDAO.deposite(ac,amt);
}
@Override
public double withdraw(long ac, double amt) throws WalletException {
	// TODO Auto-generated method stub
	return  walletDAO.withdraw(ac,amt);
}
@Override
public double fundsTransfer(long ac, long ac1, double amt) throws WalletException {
	return walletDAO.fundsTransfer(ac,ac1,amt);
}
/*@Override
public Transaction printTransactions(long ac) throws WalletException {
	// TODO Auto-generated method stub
	return walletDAO.printTransactions(ac);
}*/
@Override
public HashMap<String, Transaction> printTransactions(long accountNo) throws WalletException {
	
	 
	return walletDAO.printTransactions(accountNo);
}

}
