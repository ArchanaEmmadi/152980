package org.cap.rest.PaymentRest.service;

import java.util.List;

import org.cap.rest.PaymentRest.dao.IPaymentBankDao;
import org.cap.rest.PaymentRest.dao.IPaymentDao;
import org.cap.rest.PaymentRest.model.BankAccount;
import org.cap.rest.PaymentRest.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("paymentService")
public class PaymentServiceImp implements IPaymentService{
@Autowired
private IPaymentDao paymentDao;
@Autowired
	private IPaymentBankDao paymentBankDao;
	@Override
	public List<Transaction> getAlltrans() {
		return paymentDao.findAll();
	}

	@Override
	public void saveCreditTransaction(Transaction trans) {
		paymentDao.save(trans);
		
	}
	@Override
	public void saveDebitTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}

	@Override
	public void saveNetBankingTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}

	@Override
	public void saveCashOnDeliveryTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}

	@Override
	public List<BankAccount> getAllbAccounts() {
		return paymentBankDao.findAll();
	}

	@Override
	public BankAccount getTransaction(Long creditCardNum, Integer creditCardCvv) {
		// TODO Auto-generated method stub
		return paymentBankDao.getTransaction(creditCardNum,creditCardCvv);
	}

	@Override
	public BankAccount getNetTransaction(Long netBankingNum) {
		return paymentBankDao.getNetTransaction(netBankingNum);
	}
	

}
