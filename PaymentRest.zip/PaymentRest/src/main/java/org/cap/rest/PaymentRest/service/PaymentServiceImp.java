package org.cap.rest.PaymentRest.service;

import java.util.List;

import org.cap.rest.PaymentRest.dao.IPaymentDao;
import org.cap.rest.PaymentRest.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("paymentService")
public class PaymentServiceImp implements IPaymentService{
@Autowired
private IPaymentDao paymentDao;
	
	@Override
	public List<Transaction> getAlltrans() {
		return paymentDao.findAll();
	}

	@Override
	public void saveCreditTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}

	@Override
	public void saveDebitTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}

	@Override
	public void saveNetBankingTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}

	@Override
	public void saveCashOnDeliveryTransaction(Transaction transaction) {
		paymentDao.save(transaction);
		
	}
	

}
