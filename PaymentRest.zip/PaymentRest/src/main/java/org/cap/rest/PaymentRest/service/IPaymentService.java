package org.cap.rest.PaymentRest.service;

import java.util.List;

import org.cap.rest.PaymentRest.model.Transaction;





public interface IPaymentService {

	public List<Transaction> getAlltrans();
	public void saveCreditTransaction(Transaction transaction);
	public void saveDebitTransaction(Transaction transaction);
	public void saveNetBankingTransaction(Transaction transaction);
	public void saveCashOnDeliveryTransaction(Transaction transaction);
	
}
