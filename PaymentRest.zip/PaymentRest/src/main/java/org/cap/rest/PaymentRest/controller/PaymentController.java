package org.cap.rest.PaymentRest.controller;

import java.util.List;

import org.cap.rest.PaymentRest.model.Transaction;
import org.cap.rest.PaymentRest.service.IPaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/api/v1")
public class PaymentController {

		@Autowired
		private IPaymentService paymentService;
		
		
		
		@GetMapping("/transactions")
		public ResponseEntity<List<Transaction>> getAllTransactions(){
			List<Transaction> transactions= paymentService.getAlltrans();
			if(transactions.isEmpty()||transactions==null)
				return new ResponseEntity
					("Sorry! No trasaction details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<Transaction>>(transactions,HttpStatus.OK);
		}

		
		
		@PostMapping("/creditCard")
		public ResponseEntity<Transaction> createCreditTransaction(@RequestBody Transaction transaction){
			paymentService.saveCreditTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		@PostMapping("/debitCard")
		public ResponseEntity<Transaction> createDebitTransaction(@RequestBody Transaction transaction){
			paymentService.saveDebitTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		@PostMapping("/netBanking")
		public ResponseEntity<Transaction> createNetBankingTransaction(@RequestBody Transaction transaction){
			paymentService.saveNetBankingTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		@PostMapping("/cashOnDelivery")
		public ResponseEntity<Transaction> createCashOnDeliveryTransaction(@RequestBody Transaction transaction){
			paymentService.saveCashOnDeliveryTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		