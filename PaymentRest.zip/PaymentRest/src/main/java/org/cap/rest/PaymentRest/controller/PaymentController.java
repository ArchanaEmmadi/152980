package org.cap.rest.PaymentRest.controller;

import java.util.List;

import org.cap.rest.PaymentRest.model.Transaction;
import org.cap.rest.PaymentRest.service.IPaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/api/v1")
public class PaymentController {

		@Autowired
		private IPaymentService paymentService;
		
		
		
		@GetMapping("/transactions")
		public ResponseEntity<List<Transaction>> getAllTransactions(){
			List<Transaction> transactions= paymentService.getAlltrans();
			if(transactions.isEmpty()||transactions==null)
				return new ResponseEntity
					("Sorry! No trasaction details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<Transaction>>(transactions,HttpStatus.OK);
		}

		
		
		@PostMapping("/creditCard")
		public ResponseEntity<Transaction> createCreditTransaction(@RequestBody Transaction transaction){
			paymentService.saveCreditTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*@PostMapping("/validation")
		public String validation(ModelMap map, @RequestParam("cardno") Integer cardNumber,@RequestParam("cvv") Integer cvvNo)
		{
				
			
			BankAccount account= paymentService.findPilot(cardNumber);
			if(account!=null)
			{
				List<Pilot> pilots=pilotService.getAll();
				map.put("pilots", pilots);
				map.put("pilot", new Pilot());
				
				return "pilotFrom";
				
			}
			else
			{
			return "redirect:/";}
		}
			
	}*/
		
		
		
		



			
//		@RequestMapping("/pilotForm")
//		public String getPilotForm(ModelMap map)
//		{
//			List<Pilot> pilots=pilotService.getAll();
//			map.put("pilots", pilots);
//			if(pilot!=null)
//				map.put("pilot", pilot);
//			else
//			map.put("pilot",new Pilot());
//			return "pilotForm";
//			
//		}
		
		/*@GetMapping("/pilots")
		public ResponseEntity<List<Pilot>> getAllPilots(){
			List<Pilot> pilots= pilotService.getAll();
			if(pilots.isEmpty()||pilots==null)
				return new ResponseEntity
					("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
		}
		
		
		@PostMapping("/pilots")
		public ResponseEntity<Pilot> createPilot(@RequestBody Pilot pilot){
			pilotService.save(pilot);
			
			return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
		}
		
		
		@DeleteMapping("/pilots/{pilotId}")
		public void deletePilot(@PathVariable("pilotId") Integer pilotId) {
			
			pilotService.delete(pilotId);
			
		}*/
		
		
		
		
		
	}


