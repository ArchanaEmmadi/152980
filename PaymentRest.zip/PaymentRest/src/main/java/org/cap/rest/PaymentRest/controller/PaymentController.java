package org.cap.rest.PaymentRest.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.rest.PaymentRest.model.BankAccount;
import org.cap.rest.PaymentRest.model.Transaction;
import org.cap.rest.PaymentRest.service.IPaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/api/v1")
public class PaymentController {

		@Autowired
		private IPaymentService paymentService;
		
		
		
		@GetMapping("/transactions")
		public ResponseEntity<List<Transaction>> getAllTransactions(){
			List<Transaction> transactions= paymentService.getAlltrans();
			if(transactions.isEmpty()||transactions==null)
				return new ResponseEntity
					("Sorry! No trasaction details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<Transaction>>(transactions,HttpStatus.OK);
		}

		
		
		/*@GetMapping("/creditCard/{creditCardNum}/{creditCardCvv}")
		public ResponseEntity<BankAccount> createCreditTransaction(@PathVariable("creditCardNum") Long creditCardNum,@PathVariable("creditCardCvv") Integer creditCardCvv){
			BankAccount b=paymentService.getTransaction(creditCardNum,creditCardCvv);
			return new ResponseEntity<BankAccount>(b,HttpStatus.OK);
		}*/
		
		@GetMapping("/checkCard/{creditCardNum}/{creditCardCvv}")
		public ResponseEntity<BankAccount> checkCreditTransaction(@PathVariable("creditCardNum") Long creditCardNum,@PathVariable("creditCardCvv") Integer creditCardCvv){
			BankAccount b=paymentService.getTransaction(creditCardNum,creditCardCvv);
			
			return new ResponseEntity<BankAccount>(b,HttpStatus.OK);
		}
		@PostMapping("/creditCard")
		public ResponseEntity<Transaction> saveCreditTransaction(@RequestBody Transaction transaction){
			paymentService.saveCreditTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		
		/*
		@GetMapping("/debitCard/{debitCardNum}/{debitCardCvv}")
		public ResponseEntity<BankAccount> createDebitTransaction(@PathVariable("debitCardNum") Long debitCardNum,@PathVariable("debitCardCvv") Integer debitCardCvv){
			BankAccount b=paymentService.getTransaction(debitCardNum,debitCardCvv);
			return new ResponseEntity<BankAccount>(b,HttpStatus.OK);
		}*/
		
		@GetMapping("/checkDebitCard/{debitCardNum}/{debitCardCvv}")
		public ResponseEntity<BankAccount> checkDebitTransaction(@PathVariable("debitCardNum") Long debitCardNum,@PathVariable("debitCardCvv") Integer debitCardCvv){
			BankAccount b=paymentService.getTransaction(debitCardNum,debitCardCvv);
			
			return new ResponseEntity<BankAccount>(b,HttpStatus.OK);
		}
		
		@PostMapping("/debitCard")
		public ResponseEntity<Transaction> saveDebitTransaction(@RequestBody Transaction transaction){
			paymentService.saveDebitTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		/*@GetMapping("/netBanking/{netBankingNum}")
		public ResponseEntity<BankAccount> createNetBankingTransaction(@PathVariable("netBankingNum") Long netBankingNum){
			BankAccount b=paymentService.getNetTransaction(netBankingNum);
			return new ResponseEntity<BankAccount>(b,HttpStatus.OK);
		}*/
		
		@GetMapping("/checkNetBankCard/{netBankingNum}")
		public ResponseEntity<BankAccount> checkNetBankingTransaction(@PathVariable("netBankingNum") Long netBankingNum){
			BankAccount b=paymentService.getNetTransaction(netBankingNum);
			
			return new ResponseEntity<BankAccount>(b,HttpStatus.OK);
		}
		
		
		
		@PostMapping("/netBanking")
		public ResponseEntity<Transaction> saveNetBankingTransaction(@RequestBody Transaction transaction){
			paymentService.saveNetBankingTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		@PostMapping("/cashOnDelivery")
		public ResponseEntity<Transaction> createCashOnDeliveryTransaction(@RequestBody Transaction transaction){
			paymentService.saveCashOnDeliveryTransaction(transaction);
			
			return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
		}
		
		
}


