package org.cap.rest.PaymentRest.dao;



import javax.transaction.Transactional;

import org.cap.rest.PaymentRest.model.BankAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository("paymentBankDao")
@Transactional
public interface IPaymentBankDao extends JpaRepository<BankAccount,Integer>{
@Query("select b from BankAccount b where b.cardNumber= ?1 and b.cvvNumber=?2")
	public BankAccount getTransaction(Long l1,Integer i);
@Query("select b from BankAccount b where b.accountNumber= ?1")
public BankAccount getNetTransaction(Long netBankingNum);
	
}
