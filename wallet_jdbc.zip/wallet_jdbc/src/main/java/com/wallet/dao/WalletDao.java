package com.wallet.dao;

import java.time.LocalDate;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;

public interface WalletDao {

	public String createAccount(Customer c, Account a) throws WalletException;
	public String showBalance(String accNumber) throws WalletException;
	public String deposit(String acc, String amt) throws WalletException;
	public String withdraw(String acc, String amt) throws WalletException;
	
	public boolean checkAccountExist(String acc) throws WalletException;
	public boolean checkAccountPassword(String acc, String pass) throws WalletException;
	
	public String fundTransfer(String acc, String amt, String rAcc) throws WalletException;

	public String transaction(String transaction_type, LocalDate transaction_date, String transaction_sender, String transaction_receiver, String transaction_status, String transaction_amount) throws WalletException;
	
	public HashMap<String,Transaction> printTransaction(String acc) throws WalletException; 
}
