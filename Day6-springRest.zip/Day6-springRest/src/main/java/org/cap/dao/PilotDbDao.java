package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Transactional

@Repository("pDbDao")
public class PilotDbDao implements PilotDao{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<Pilot> getAll() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		Pilot pilot=entityManager.find(Pilot.class,pilotId );
		return pilot;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
		return getAll();
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		// TODO Auto-generated method stub
		entityManager.persist(pilot);
		return getAll();
		
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		Pilot pilot1= entityManager.find(Pilot.class, pilot.getPilotId());
		if(pilot1==null)
		{
			entityManager.persist(pilot);

		}
		else
		entityManager.merge(pilot);
		return getAll();
	}
		
		
}
