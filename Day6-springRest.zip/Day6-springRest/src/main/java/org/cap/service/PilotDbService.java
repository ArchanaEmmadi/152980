package org.cap.service;

import java.util.List;

import org.cap.dao.PilotDao;
//import org.cap.dao.PilotDao;
import org.cap.dao.PilotDbDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("pDbService")
public class PilotDbService implements PilotService{
	@Autowired
	private PilotDao pDbDao;
	@Override
	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		return pDbDao.getAll();
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return pDbDao.findPilot(pilotId);
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return pDbDao.deletePilot(pilotId);
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		// TODO Auto-generated method stub
		return pDbDao.createPilot(pilot);
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		// TODO Auto-generated method stub
		return pDbDao.updatePilot(pilot);
	}

}
